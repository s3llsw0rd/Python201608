SELECT * FROM user
LEFT JOIN friendship ON friendship.user_id = user.id
LEFT JOIN user as user2 ON user2.id = friendship.friend_id
